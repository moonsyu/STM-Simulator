import fs from 'node:fs/promises';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {blankProject} from '../../src/project.js';
import {PART_DEFS} from '../../src/components.js';
import {applyDeviceExample} from '../../src/device-assistance.js';
import {wiringTopology} from '../../src/device-docs-data.js';
import {cFunctions} from '../../src/c-source-edit.js';
import {execute} from '../../scripts/docs-audit/runtime.mjs';

const out=new URL('./final/',import.meta.url);
const root=fileURLToPath(new URL('../../',import.meta.url));
const git=(...args)=>execFileSync('git',args,{cwd:root,encoding:'utf8'}).trim();
const sha=value=>createHash('sha256').update(typeof value==='string'||Buffer.isBuffer(value)?value:JSON.stringify(value)).digest('hex');
async function sourceIdentity(){const files=git('ls-files','src','desktop','package.json').split(/\r?\n/).filter(Boolean),chunks=[];for(const file of files)chunks.push(file+'\0'+sha(await fs.readFile(path.join(root,file))));return sha(chunks.join('\n'));}
const sourceSha256=await sourceIdentity(),packageVersion=JSON.parse(await fs.readFile(path.join(root,'package.json'),'utf8')).version;
const report={packageVersion,nodeVersion:process.version,sourceCommit:git('rev-parse','HEAD'),sourceDirty:!!git('status','--porcelain'),sourceStatus:git('status','--porcelain'),sourceSha256,startedAt:new Date().toISOString(),scope:'Independent source Node/SimulationSession, current working tree. No Electron, public EXE, physical MCU or user profile.',cases:[],limitations:[
  'Selected multi-device combinations and conflict boundaries only; not all possible combinations of 114 device types.',
  'Docs blocks execute sequentially in main. HAL_Delay and polling can delay later blocks; successful composition does not imply concurrent scheduling.',
  'Conflict cases prove atomic rejection of the input project and repeatable execution of the existing project; the rejected new combination is not executed.',
  'Existing execute harness retains at most 120 printf records, 50 UART events, 30 bus traces, and milestone state frames.'
]};
await fs.mkdir(out,{recursive:true});
const save=async(name,data)=>fs.writeFile(new URL(name,out),JSON.stringify(data,null,2)+'\n');
function add(p,type,id,extra={}){p.components.push({id,type,name:id,x:800+150*p.components.length,y:350,rotation:0,span:70,...PART_DEFS[type]?.defaults,...extra});}
function apply(p,id){return applyDeviceExample(p,{type:'part',id}).project;}
function contract(p,n){assert.equal(p.deviceDocs.bindings.length,n);assert.equal(cFunctions(p.code).filter(f=>f.name==='main').length,1);assert.equal(p.firmware.files.length,0);assert.doesNotMatch(p.code,/\bSTM_Devices_(Init|Step)\s*\(/);}
function healthy(e){assert.equal(e.error,null,JSON.stringify(e.error));assert.ok(e.frames.length>1);assert.ok(e.frames.every(f=>f.fault===false));}
async function runtime(name,p,options={}){const e=execute(p,{stimulus:false,...options});await save(name+'-runtime.json',e);await save(name+'-project.json',p);return e;}
async function audit(id,fn){const row={id,passed:false};report.cases.push(row);try{Object.assign(row,await fn());row.passed=true;}catch(error){row.error=error.stack;}console.log(id+': '+(row.passed?'PASS':'FAIL'));await save('results.json',report);}
async function atomic(name,p,target,pattern,{end=300}={}){
 const before=JSON.stringify(p),codeBefore=sha(p.code),wiresBefore=sha(p.wires),baseline=await runtime(name+'-before',p,{end});
 healthy(baseline);let message='';try{applyDeviceExample(p,target);}catch(error){message=error.message;}
 const preserved=JSON.stringify(p)===before;
 const e=await runtime(name+'-after',p,{end});healthy(e);
 const proof={error:message,originalUnchanged:preserved,beforeSha256:sha(before),afterSha256:sha(p),codeSha256:codeBefore,wiresSha256:wiresBefore,runtimeBeforeSha256:sha(baseline),runtimeAfterSha256:sha(e),existingRuntimeUnchanged:sha(baseline)===sha(e)};
 await save(name+'-atomic.json',proof);assert.match(message,pattern);assert.ok(preserved);assert.ok(proof.existingRuntimeUnchanged);return proof;
}

await audit('two-servos-independent-timers',async()=>{
 let p=blankProject();add(p,'servo','servoA');add(p,'servo','servoB');p=apply(apply(p,'servoA'),'servoB');contract(p,2);
 const bindings=p.deviceDocs.bindings,timers=bindings.map(b=>b.peripherals.TIM2);assert.notEqual(...timers);
 const e=await runtime('two-servos',p,{end:7500});healthy(e);
 const states={};for(const id of ['servoA','servoB']){const samples=e.frames.map(f=>({atMs:f.atMs,...f.parts[id]}));states[id]=samples;
  for(const pulse of [1000,1500,2000])assert.ok(samples.some(v=>v.on&&Math.abs(v.pulse-pulse)<2),id+' pulse '+pulse);
  for(const angle of [0,90,180])assert.ok(samples.some(v=>v.on&&Math.abs(v.angle-angle)<2),id+' angle '+angle);
 }
 assert.ok(e.frames.some(f=>f.parts.servoA.on&&f.parts.servoB.on));await save('two-servos-observations.json',states);
 return {bindings,timers,runtimeLog:'two-servos-runtime.json',observations:'two-servos-observations.json',note:'Each servo reaches all three commanded angles; their main-loop commands are staggered by sequential 1200 ms delays.'};
});

await audit('two-i2c-sensors-shared-bus-distinct-addresses',async()=>{
 let p=blankProject();add(p,'sht31','sensorA',{address:0x44,temperature:10,humidity:25});add(p,'sht31','sensorB',{address:0x45,temperature:40,humidity:75});p=apply(apply(p,'sensorA'),'sensorB');contract(p,2);
 const bindings=p.deviceDocs.bindings;assert.equal(bindings[0].peripherals.I2C1,bindings[1].peripherals.I2C1);
 const uf=wiringTopology(p);for(const n of [3,4])assert.equal(uf.find('part:sensorA:p'+n),uf.find('part:sensorB:p'+n));
 const e=await runtime('i2c-distinct',p,{end:3500});healthy(e);const text=e.printed.map(p=>p.text).join('\n');
 assert.match(text,/10\.0 C RH=25\.0/);assert.match(text,/40\.0 C RH=75\.0/);assert.doesNotMatch(text,/CRC error|timeout/i);
 for(const address of ['0x44','0x45']){assert.ok(e.trace.some(v=>v.message.includes(address+' READ 6 B')&&v.message.includes('ACK')));assert.ok(e.trace.some(v=>v.message.includes(address+' WRITE')&&v.message.includes('ACK')));}
 return {bindings,addresses:[0x44,0x45],runtimeLog:'i2c-distinct-runtime.json',printed:e.printed};
});

await audit('duplicate-i2c-address-rejected-atomically',async()=>{
 let p=blankProject();add(p,'sht31','sensorA',{address:0x44});add(p,'sht31','sensorB',{address:0x44});p=apply(p,'sensorA');
 return atomic('i2c-duplicate',p,{type:'part',id:'sensorB'},/같은 I2C 버스.*0x44/,{end:1200});
});

await audit('two-uarts-distinct-instances-and-rx-tx',async()=>{
 let p=blankProject();add(p,'uart','uartA',{baud:9600});add(p,'uart','uartB',{baud:115200});p=apply(apply(p,'uartA'),'uartB');contract(p,2);
 const bindings=p.deviceDocs.bindings,instances=bindings.map(b=>b.peripherals.USART2);assert.notEqual(...instances);
 const e=await runtime('two-uarts',p,{end:400,onTick:({time,session})=>{if(time===100){assert.equal(session.inject('A7',instances[0]+':external'),2);assert.equal(session.inject('B9',instances[1]+':external'),2);}}});healthy(e);
 const received=e.frames.at(-1).received;for(const [id,message,other]of [['uartA','A7','B9'],['uartB','B9','A7']]){assert.match(received[id],/HAL UART ready/);assert.ok(received[id].endsWith(message));assert.ok(!received[id].includes(other));}
 for(const [i,message]of ['A7','B9'].entries()){const bytes=e.uart.filter(v=>v.instance===instances[i]&&v.direction==='RX').flatMap(v=>v.bytes);assert.equal(String.fromCharCode(...bytes),message);}
 return {bindings,instances,baud:instances.map(id=>p.mcu.peripherals[id].baud),received,runtimeLog:'two-uarts-runtime.json'};
});

await audit('seventh-uart-resource-exhaustion-rejected-atomically',async()=>{
 let p=blankProject();for(let i=0;i<7;i++)add(p,'uart','uart'+i);for(let i=0;i<6;i++)p=apply(p,'uart'+i);contract(p,6);
 const instances=p.deviceDocs.bindings.map(b=>b.peripherals.USART2);assert.equal(new Set(instances).size,6);
 const proof=await atomic('uart-exhausted',p,{type:'part',id:'uart6'},/사용 가능한 UART TX\/RX 핀 조합이 없습니다/,{end:400});
 const final=JSON.parse(await fs.readFile(new URL('uart-exhausted-after-runtime.json',out),'utf8')).frames.at(-1);for(let i=0;i<6;i++)assert.match(final.received['uart'+i],/HAL UART ready/);
 return {instances,...proof};
});

await audit('edited-docs-region-reapply-rejected-with-original-preserved',async()=>{
 let p=blankProject();add(p,'led','ledA',{color:'red'});p=apply(p,'ledA');
 p.code=p.code.replace('/* STM DEVICE DOCS STEP BEGIN */','/* STM DEVICE DOCS STEP BEGIN */\n// personal change');
 assert.match(p.code,/personal change/);return atomic('edited-region',p,{type:'part',id:'ledA'},/장치 예제 영역이 직접 수정/,{end:1200});
});


await audit('same-device-hal-card-replaces-prior-operation',async()=>{
 let p=blankProject();add(p,'led','ledA',{color:'red'});
 const target={type:'part',id:'ledA'},first=applyDeviceExample(p,target,{api:'HAL_GPIO_WritePin'}).project;
 const second=applyDeviceExample(first,target,{api:'HAL_GPIO_TogglePin'}).project;
 const third=applyDeviceExample(second,target,{api:'HAL_GPIO_WritePin'}).project;
 const results=[];
 for(const [label,project,api]of [['write',first,'HAL_GPIO_WritePin'],['toggle',second,'HAL_GPIO_TogglePin'],['write-again',third,'HAL_GPIO_WritePin']]){
  contract(project,1);assert.equal(project.deviceDocs.bindings[0].api,api);
  assert.equal(sha(project.wires),sha(first.wires));assert.equal(sha(project.components),sha(first.components));
  const e=await runtime('same-card-'+label,project,{end:1200});healthy(e);const states=e.frames.map(f=>({atMs:f.atMs,on:f.parts.ledA.on}));
  if(label==='toggle'){assert.ok(states.some(v=>v.on));assert.ok(states.some(v=>!v.on));}
  else assert.ok(states.every(v=>v.on));
  results.push({operation:api,bindingCount:project.deviceDocs.bindings.length,states,runtimeLog:'same-card-'+label+'-runtime.json'});
 }
 return {behavior:'Applying another HAL card to the same device replaces its previous managed example; it does not append another operation or binding.',results};
});

report.summary={total:report.cases.length,passed:report.cases.filter(v=>v.passed).length,failed:report.cases.filter(v=>!v.passed).length};
report.sourceSha256After=await sourceIdentity();report.sourceUnchanged=report.sourceSha256After===report.sourceSha256;report.finishedAt=new Date().toISOString();
report.passed=report.summary.failed===0&&report.sourceUnchanged;
await save('results.json',report);console.log(JSON.stringify(report.summary));process.exitCode=report.passed?0:1;
